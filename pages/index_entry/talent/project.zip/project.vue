<template>
	<view>
		<view class="header_">
			
			<view class="wrapper_search trans" 
				@click="navigate('/pages/search/search')"
				:style="[{marginTop:m_top},{width:m_left}]">
				<u-search :show-action="false" 
					clearabled="false" disabled="false" 
					placeholder="搜索" 
					v-model="m_search" shape="round"
					bg-color="#efefef">
				</u-search>
			</view>
			
			<u-dropdown class="achievement"
				ref="uDropdown"
				:border-bottom="true">
				<u-dropdown-item 
					:key="index"
					v-for="(item,index) in project_dropdown"
					v-model="event[index].m" 
					:title="item[event[index].m-10*index].label" 
					:options="item" 
					@change="change">
				</u-dropdown-item>
			</u-dropdown>
		</view>
		<view class="item">
			<view class="swiper-box">
				<scroll-view scroll-y
					class="swiper-item"
					@scrolltoupper="reachTop"
					@scrolltolower="reachBottom">
					<view
						v-for="(projectItem,projectIndex) in index_project"
						:key="projectIndex">
						<team-project :projectItem="projectItem">
						</team-project>
					</view>
					<u-loadmore :status="loadStatus" bgColor="transparent"></u-loadmore>
				</scroll-view>
			</view>
		</view>
		
	</view>
</template>

<script>
	var m_this;
	import {
		index_data_refresh
	} from "@/api/mock.js";
	import teamProject from "@/components/team-project/team-project.vue";
	
	export default {
		components:{
			teamProject
		},
		data() {
			return {
				event: [{m:0},{m:10}], 
				project_dropdown:[
					[
						{
							label:"发帖时间",
							value:0
						},
						{
							label:"热度",
							value:1
						},
						{
							label:"项目周期",
							value:2
						},
						{
							label:"需求人数",
							value:3
						}
					],
					[
						{
							label:"由高到低",
							value:10
						},
						{
							label:"由低到高",
							value:11
						
						}
					]
				],
				tabsHeight: 0,
				dx: 0,
				loadStatus: 'loadmore',
				
				m_height: "100px",
				scrollHeight: 0,
				tab_list: [{
					name: '项目圈',
					num: 1
				}, {
					name: '人才圈',
					num: 1
				}, {
					name: '问答圈',
					num: 1
				}],
				m_search: "",
				m_alias: 'RyanAlexander',
				m_avatar: 'http://sayhitotheworld.ryanalexander.cn/team/talent/ryan.jpg',
				m_top: 0,
				m_width: 0,
				m_left: 0,
				m_height_header: 30,
				m_header_shadow: '0000',
				m_header_opacity: '0000',
				m_tab_shadow: '0000',
				m_tab_opacity: '0000',
				m_tab_bgcolor: "transparent",
				m_header_color: '#ffffff',
				m_header_middle_msg: 9,
				
				m_uid: 0,
				m_access: '',
				m_news_navigate: '/pages/news/news?',
				
				index_project: []
			};
		},
		onLoad() {
			m_this = this;
			this.m_height = uni.getSystemInfoSync().windowHeight
			
			this.m_left = (uni.getStorageSync("left") - 26) + 'px';
			
			this.m_width = uni.getStorageSync("width");
			
			this.m_top = (uni.getStorageSync("top") - this.m_width / 2) + 'px';
			
			this.m_uid = uni.getStorageSync("uid");
			this.m_access = uni.getStorageSync("a");
			
			index_data_refresh(0,5).then(function(value){
				m_this.index_project=value;
			});
		},
		methods:{
			reachTop() {
			},
			reachBottom() {
			
				m_this.loadStatus="loading";
				index_data_refresh(0,2).then(function(value){
					m_this.index_project.push.apply(m_this.index_project,value);
					// console.log(index[m_this.current])
					// console.log(m_this.current)
					m_this.loadStatus="loading";
				});
				
			},
			
			change: async function(e){
				// _this.ani_if = false;
				
				
				
				// _this.$nextTick(() => {
				// 	_this.ani_if = true;
				// });
				// await _this.sort_(_this.event);
				// _this.fadeInUp();
			},
			navigate(navigation) {
				uni.navigateTo({
					url: navigation,
					success: res => {},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style lang="scss">
	@import  "@/common/uni.scss";
	@import "./project.scss";
	
	
</style>
